package com.mall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MallManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
